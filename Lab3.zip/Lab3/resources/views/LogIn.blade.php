@extends('layouts.app')
@section('title')

    Homepage

@endsection
@section('phpempty')

@endsection
@section('contentlogin')
<table>
<tr><td>
<h2>
LogInPage
</h2></td></tr>
	<tr><td>
<h2>
	<input type="text" name="firstname">
</h2></td><td>
<h2>
<input type="password" name="password">
</h2>
</td><td>
<h2>
<input type="submit" name="LogIn" value="LogIn">
</h2></td></tr>
<table>	
	
	

   
@endsection