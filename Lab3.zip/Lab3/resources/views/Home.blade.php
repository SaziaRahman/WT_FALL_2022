@extends('layouts.app')
@section('title')

    Homepage

@endsection
@section('phpempty')

@endsection
@section('content')
<table>
<tr><td>
<h2>
Homepage
</h2></td></tr>
	<tr><td>
<h2>
	<a href="\register"> Register </a>
</h2></td><td>
<h2>
<a href="\login"> LogIn </a>
</h2></td></tr>
<table>	
	
	

   
@endsection