
<?php $__env->startSection('title'); ?>

    Homepage

<?php $__env->stopSection(); ?>
<?php $__env->startSection('phpempty'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentregister'); ?>
<table>
<tr><td>
<h2>
RegisterPage
</h2></td></tr>
<tr><td>
<h4>
	Firstname:
</h4></td><td>
<h4>
Password:
</h4>
</td></tr>
	<tr><td>
<h2>
	<input type="text" name="firstname" value="<?php echo e(old('firstname')); ?>">
</h2></td><td>
<h2>
<input type="password" name="password" value="<?php echo e(old('password')); ?>">
</h2>
</td></tr>

<tr><td>
<h4>
	<?php if($errors->has('firstname')): ?>
    <span class="">
        <strong>
            <?php echo e($errors->first('firstname')); ?>

</strong>
</span>
    <?php endif; ?>
</h4></td><td>
<h4>
<?php if($errors->has('password')): ?>
    <span class="">
        <strong>
            <?php echo e($errors->first('password')); ?>

</strong>
</span>
    <?php endif; ?>
</h4>
</td></tr>

<tr><td>
<h4>
	Lastname:
</h4></td><td>
<h4>
Confirm Password:
</h4>
</td></tr>
	<tr><td>
<h2>
	<input type="text" name="lastname" value="<?php echo e(old('lastname')); ?>">
</h2></td><td>
<h2>
<input type="password" name="confirm_password" value="<?php echo e(old('confirm_password')); ?>">
</h2>
</td></tr>

<tr><td>
<h4>
	<?php if($errors->has('lastname')): ?>
    <span class="">
        <strong>
            <?php echo e($errors->first('lastname')); ?>

</strong>
</span>
    <?php endif; ?>
</h4></td><td>
<h4>
<?php if($errors->has('confirm_password')): ?>
    <span class="">
        <strong>
            <?php echo e($errors->first('confirm_password')); ?>

</strong>
</span>
    <?php endif; ?>
</h4>
</td></tr>

<tr><td>
<h4>
	Email:
</h4></td><td>
<h4>
MobileNo:
</h4>
</td></tr>
	<tr><td>
<h2>
	<input type="text" name="email" value="<?php echo e(old('email')); ?>">
</h2></td><td>
<h2>
<input type="text" name="mobileno" value="<?php echo e(old('mobileno')); ?>">
</h2>
</td></tr>

<tr><td>
<h4>
	<?php if($errors->has('email')): ?>
    <span class="">
        <strong>
            <?php echo e($errors->first('email')); ?>

</strong>
</span>
    <?php endif; ?>
</h4></td><td>
<h4>
<?php if($errors->has('mobileno')): ?>
    <span class="">
        <strong>
            <?php echo e($errors->first('mobileno')); ?>

</strong>
</span>
    <?php endif; ?>
</h4>
</td></tr>

<tr><td>
<h4>
	Details:
</h4></td></tr>
	<tr><td>
<h2>
	<textarea name="details" placeholder="Enter Details"><?php echo e(old('details')); ?></textarea>
</h2></td></tr>

<tr><td>
<h4>
	<?php if($errors->has('details')): ?>
    <span class="">
        <strong>
            <?php echo e($errors->first('details')); ?>

</strong>
</span>
    <?php endif; ?>
</h4></td></tr>

<tr><td>
<h2>
<input type="submit" name="Insert" value="Insert">

<input type="submit" name="Update" value="Update">
</h2></td></tr>
<table>	
	
	

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp123\htdocs\Lab3\resources\views/Register.blade.php ENDPATH**/ ?>