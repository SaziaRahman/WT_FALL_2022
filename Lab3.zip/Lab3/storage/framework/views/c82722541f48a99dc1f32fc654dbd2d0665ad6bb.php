
<?php $__env->startSection('title'); ?>

    Profilepage

<?php $__env->stopSection(); ?>
<?php $__env->startSection('phpempty'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h2>
<?php echo e(session()->get('firstname')); ?>

</h2>
<br>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentlogout'); ?>

<input type="submit" name="logout" value="logout">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp123\htdocs\Lab3\resources\views/Profile.blade.php ENDPATH**/ ?>