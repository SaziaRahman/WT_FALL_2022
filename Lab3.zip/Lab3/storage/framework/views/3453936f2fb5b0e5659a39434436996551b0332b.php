<html>
    <head>
        <title>
            <?php echo $__env->yieldContent('title'); ?>
</title>

</head>
<body>
<?php echo $__env->yieldContent('information'); ?>
<?php echo $__env->yieldContent('phpempty'); ?>
<?php echo $__env->yieldContent('content'); ?>  
<form method="POST" action="/register">	
<?php echo e(csrf_field()); ?>

<?php echo $__env->yieldContent('contentregister'); ?>	
</form>

    <form method="POST" action="/login">	
<?php echo e(csrf_field()); ?>

<?php echo $__env->yieldContent('contentlogin'); ?>	
</form>



<form method="POST" action="logout">
<?php echo e(csrf_field()); ?>

<?php echo $__env->yieldContent('contentlogout'); ?>	   
</form>

<?php echo $__env->yieldContent('phpfill'); ?> 

</body>
</html><?php /**PATH C:\xampp123\htdocs\Lab3\resources\views/layouts/app.blade.php ENDPATH**/ ?>