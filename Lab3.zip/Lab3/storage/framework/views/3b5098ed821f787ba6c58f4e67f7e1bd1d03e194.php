
<?php $__env->startSection('title'); ?>

    Homepage

<?php $__env->stopSection(); ?>
<?php $__env->startSection('phpempty'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentlogin'); ?>
<table>
<tr><td>
<h2>
LogInPage
</h2></td></tr>
	<tr><td>
<h2>
	<input type="text" name="firstname">
</h2></td><td>
<h2>
<input type="password" name="password">
</h2>
</td><td>
<h2>
<input type="submit" name="LogIn" value="LogIn">
</h2></td></tr>
<table>	
	
	

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp123\htdocs\Lab3\resources\views/LogIn.blade.php ENDPATH**/ ?>