<html>
    <head>
        <title>
            @yield('title')
</title>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
@yield('information')
@yield('phpempty')  

@yield('content')

@yield('phpfill') 

</body>
</html>