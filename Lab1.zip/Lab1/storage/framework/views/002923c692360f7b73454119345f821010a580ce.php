<html>
    <head>
        <title>
            <?php echo $__env->yieldContent('title'); ?>
</title>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<?php echo $__env->yieldContent('information'); ?>
<?php echo $__env->yieldContent('phpempty'); ?>  

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('phpfill'); ?> 

</body>
</html><?php /**PATH C:\xampp123\htdocs\Lab1\resources\views/layouts/app.blade.php ENDPATH**/ ?>