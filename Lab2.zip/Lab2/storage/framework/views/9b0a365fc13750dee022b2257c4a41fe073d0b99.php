
<?php $__env->startSection('title'); ?>

    Registerpage

<?php $__env->stopSection(); ?>
<?php $__env->startSection('phpempty'); ?>
<?php 
$register="/register";
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<h2>Form Validation</h2>
	<form method="POST" action="/register" autocomplete="off">


		<?php if(count($errors)): ?>
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.
				<br/>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>


		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">


		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('firstname') ? 'has-error' : ''); ?>">
					<label for="firstname">First Name:</label>
					<input type="text" id="firstname" name="firstname" class="form-control" placeholder="Enter First Name" value="<?php echo e(old('firstname')); ?>">
					<span class="text-danger"><?php echo e($errors->first('firstname')); ?></span>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('lastname') ? 'has-error' : ''); ?>">
					<label for="lastname">Last Name:</label>
					<input type="text" id="lastname" name="lastname" class="form-control" placeholder="Enter Last Name" value="<?php echo e(old('lastname')); ?>">
					<span class="text-danger"><?php echo e($errors->first('lastname')); ?></span>
				</div>
			</div>
		</div>


		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
					<label for="email">Email:</label>
					<input type="text" id="email" name="email" class="form-control" placeholder="Enter Email" value="<?php echo e(old('email')); ?>">
					<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('mobileno') ? 'has-error' : ''); ?>">
					<label for="mobileno">Mobile No:</label>
					<input type="text" id="mobileno" name="mobileno" class="form-control" placeholder="Enter Mobile No" value="<?php echo e(old('mobileno')); ?>">
					<span class="text-danger"><?php echo e($errors->first('mobileno')); ?></span>
				</div>
			</div>
		</div>


		<div class="row">
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
					<label for="password">Password:</label>
					<input type="password" id="password" name="password" class="form-control" placeholder="Enter Password" >
					<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
					<label for="confirm_password">Confirm Password:</label>
					<input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Enter Confirm Passowrd">
					<span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
				</div>
			</div>
		</div>


		<div class="row">
			<div class="col-md-12">
				<div class="form-group <?php echo e($errors->has('details') ? 'has-error' : ''); ?>">
					<label for="details">Details:</label>
					<textarea name="details" id="details" class="form-control" placeholder="Enter Details"><?php echo e(old('details')); ?></textarea>
					<span class="text-danger"><?php echo e($errors->first('details')); ?></span>
				</div>
			</div>
		</div>


		<div class="col-md-1">
			<input type="submit" value="Insert" name="Insert" class="btn btn-success">

		</div>
		<div class="col-md-1">
			<input type="submit" value="Update" name="Update" class="btn btn-info">
		</div>


	</form>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp123\htdocs\Lab1\resources\views/register.blade.php ENDPATH**/ ?>