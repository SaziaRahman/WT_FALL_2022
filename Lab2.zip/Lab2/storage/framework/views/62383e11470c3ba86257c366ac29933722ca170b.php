
<?php $__env->startSection('title'); ?>

    Homepage

<?php $__env->stopSection(); ?>
<?php $__env->startSection('phpempty'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<h2>Form LogIn</h2>
	
	<form method="POST" action="/home">
	<?php if(count($errors)): ?>
	
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.
				<br/>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
	
		<?php endif; ?>

		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">


		<div class="row">
			<div class="col-md-6">
				<div class="form-group2 <?php echo e($errors->has('firstname') ? 'has-error' : ''); ?>">
					<label for="firstname">First Name:</label>
					<input type="text" id="firstname" name="firstname" class="form-control" placeholder="Enter First Name" value="<?php echo e(old('firstname')); ?>">
					
				</div>
			</div>
			


		<div class="row">
			<div class="col-md-6">
				<div class="form-group2 <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
					<label for="password">Password:</label>
					<input type="password" id="password" name="password" class="form-control" placeholder="Enter Password" >
					
				</div>
			</div>
		


		<div class="form-group2">
		<input type="submit" value="LogIn" name="LogIn" class="btn btn-success">
		</div>


	</form>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp123\htdocs\Lab1\resources\views/Home.blade.php ENDPATH**/ ?>